# Usage
helloWorldSquirrel()
# Result
```
 _____________
< hello world >
 -------------
  \
     \
                  _ _
       | \__/|  .~    ~.
       /oo `./      .'
      {o__,   \    {
        / .  . )    \
        `-` '-' \    }
       .(   _(   )_.'
      '---.~_ _ _|
                                                     
```
