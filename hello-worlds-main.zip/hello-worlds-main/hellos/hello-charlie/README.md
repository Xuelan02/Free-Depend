# Usage
helloWorldCharlie()
# Result
```
 _____________
< hello world >
 -------------
  \
   \
    \     ,, ＿
        ／      ｀､
       /   (_ﾉL_） ヽ
      /   ´・ ・｀  l
    （l      し     l）
      l     ＿＿    l
      >  ､ _      ィ
    ／        ￣    ヽ
   /  |              iヽ
   |＼|              |/|
   |  ||/＼／＼／＼/ | |
```
