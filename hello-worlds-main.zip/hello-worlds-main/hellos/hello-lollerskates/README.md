# Usage
helloWorldLollerskates()
# Result
```
 _____________
< hello world >
 -------------
   \
    \
        /\O
         /\/
        /\
       /  \
      LOL LOL
:-D LOLLERSKATES :-D
```
