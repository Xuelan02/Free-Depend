# Usage
helloWorldKnight()
# Result
```
 _____________
< hello world >
 -------------
 \
  \
  __/"""\
 ]___ 0  }
     /   }
   /~    }
   \____/
   /____\
  (______)
```
