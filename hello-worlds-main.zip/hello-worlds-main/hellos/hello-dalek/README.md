# Usage
helloWorldDalek()
# Result
```
 _____________
< hello world >
 -------------
   \
    \
              ___
      D>=G==='   '.
            |======|
            |======|
        )--/]IIIIII]
           |_______|
           C O O O D
          C O  O  O D
         C  O  O  O  D
         C__O__O__O__D
snd     [_____________]
```
