# Usage
helloWorldVader()
# Result
```
 _____________
< hello world >
 -------------
        \    ,-^-.
         \   !oYo!
          \ /./=\.\______
               ##        )\/\
                ||-----w||
                ||      ||

               Cowth Vader
```
