# Usage
helloWorldKilroy()
# Result
```
 _____________
< hello world >
 -------------
     \ 
      \
           ,,,
          (0 0)
   +---ooO-(_)-Ooo---+
   |                 |
```
