# Usage
helloWorldGoat()
# Result
```
 _____________
< hello world >
 -------------
       \
        \
         \  _))
           > o\     _~
           `;'\\__-' \_
              | )  _ \ \
             / / ``   w w
            w w
```
