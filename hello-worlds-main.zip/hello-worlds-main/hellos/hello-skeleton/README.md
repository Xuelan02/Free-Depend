# Usage
helloWorldSkeleton()
# Result
```
 _____________
< hello world >
 -------------
          \      (__)      
           \     /oo|  
            \   (_"_)*+++++++++*
                   //I#\\\\\\\\I\
                   I[I|I|||||I I `
                   I`I'///'' I I
                   I I       I I
                   ~ ~       ~ ~
                     Scowleton
```
