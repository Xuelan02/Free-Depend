# Usage
helloWorldOwl()
# Result
```
 _____________
< hello world >
 -------------
         \
          \
           ___
          (o o)
         (  V  )
        /--m-m-
```
