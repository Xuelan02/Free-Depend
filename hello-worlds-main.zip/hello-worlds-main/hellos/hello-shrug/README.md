# Usage
helloWorldShrug()
# Result
```
 _____________
< hello world >
 -------------
  \
¯\_(ツ)_/¯
```
