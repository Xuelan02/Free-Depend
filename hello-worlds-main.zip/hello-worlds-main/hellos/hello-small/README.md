# Usage
helloWorldSmall()
# Result
```
 _____________
< hello world >
 -------------
       \   ,__,
        \  (oo)____
           (__)    )\
              ||--|| *
```
