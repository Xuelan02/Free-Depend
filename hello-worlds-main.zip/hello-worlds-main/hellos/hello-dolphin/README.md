# Usage
helloWorldDolphin()
# Result
```
 _____________
< hello world >
 -------------
     \
      \
               ,
             __)\_  
       (\_.-'    a`-.
  jgs  (/~~````(/~^^` 

```
