# Usage
helloWorldRobot()
# Result
```
 _____________
< hello world >
 -------------
  \
   \

     [-]
     (+)=C
     | |
     OOO
```
