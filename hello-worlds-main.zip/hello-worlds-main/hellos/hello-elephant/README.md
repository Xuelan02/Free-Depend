# Usage
helloWorldElephant()
# Result
```
 _____________
< hello world >
 -------------
 \     /\  ___  /\
  \   // \/   \/ \\
     ((    o o    ))
      \\ /     \ //
       \/  | |  \/ 
        |  | |  |  
        |  | |  |  
        |   o   |  
        | |   | |  
        |m|   |m|  
```
