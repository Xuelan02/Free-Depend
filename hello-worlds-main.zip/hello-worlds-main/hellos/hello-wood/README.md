# Usage
helloWorldWood()
# Result
```
 _____________
< hello world >
 -------------
  \
   \   --木--
       ／｜＼
     ／  ｜  ＼
  --木-- ｜ --木--
  ／｜＼    ／｜＼
／  ｜　＼／  ｜  ＼
    ｜        ｜
```
