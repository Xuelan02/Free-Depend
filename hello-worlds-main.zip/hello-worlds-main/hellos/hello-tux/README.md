# Usage
helloWorldTux()
# Result
```
 _____________
< hello world >
 -------------
   \
    \
        .--.
       |o_o |
       |:_/ |
      //   \ \
     (|     | )
    /'\_   _/`\
    \___)=(___/

```
