# Usage
helloWorldSachiko()
# Result
```
 _____________
< hello world >
 -------------
     \
      \
       \
             , -――- 、
          ／          ヽ、
        /爻ﾉﾘﾉﾊﾉﾘlﾉ ゝ  l
     ＜ﾉﾘﾉ‐'    ｰ  ﾘ ＞ }
        l ﾉ ┃    ┃ l ﾉ  ﾉ
        l人   r‐┐   !ﾉ＾)
           ゝ ` ´ ‐＜´
```
