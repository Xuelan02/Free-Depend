# Usage
helloWorldKitten()
# Result
```
 _____________
< hello world >
 -------------
   \
    \

     |\_/|
     |o o|__
     --*--__\
     C_C_(___)
```
