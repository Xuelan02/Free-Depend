# Usage
helloWorldSheep()
# Result
```
 _____________
< hello world >
 -------------
  \
   \
       __     
      UooU\.'@@@@@@`.
      \__/(@@@@@@@@@@)
           (@@@@@@@@)
           `YY~~~~YY'
            ||    ||
```
