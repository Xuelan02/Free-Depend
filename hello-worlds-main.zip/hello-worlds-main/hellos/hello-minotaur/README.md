# Usage
helloWorldMinotaur()
# Result
```
 _____________
< hello world >
 -------------
        \   ^__^
         \  (oo)
            (__)
           /-||-\
           \|\/|/
            o==o 
            ||||
            ()()
```
