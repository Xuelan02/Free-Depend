# Usage
helloWorldClippy()
# Result
```
 _____________
< hello world >
 -------------
 \
  \
     __ 
    /  \  
    |  |
    @  @
    |  |
    || |/ 
    || || 
    |\_/|
    \___/
```
