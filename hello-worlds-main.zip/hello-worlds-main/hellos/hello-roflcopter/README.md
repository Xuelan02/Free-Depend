# Usage
helloWorldRoflcopter()
# Result
```
 _____________
< hello world >
 -------------
   \
    \
 ROFL:ROFL:ROFL:ROFL
         _^___
 L    __/   oo \    
LOL===__        \ 
 L      \________]
         I   I    
        --------/
```
