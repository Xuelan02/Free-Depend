# Usage
helloWorldMoose()
# Result
```
 _____________
< hello world >
 -------------
  \
   \   \_\_    _/_/
    \      \__/
           (oo)\_______
           (__)\       )\/\
               ||----- |
               ||     ||
```
