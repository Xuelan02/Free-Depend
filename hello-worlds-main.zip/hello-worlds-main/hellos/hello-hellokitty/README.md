# Usage
helloWorldHellokitty()
# Result
```
 _____________
< hello world >
 -------------
  \
   \
      /\_)o<
     |      \
     | o . o|
      \_____/
           
```
