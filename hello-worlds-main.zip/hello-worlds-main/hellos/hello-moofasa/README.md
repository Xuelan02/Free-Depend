# Usage
helloWorldMoofasa()
# Result
```
 _____________
< hello world >
 -------------
       \    ____
        \  /    \
          | ^__^ |
          | (oo) |______
          | (__) |      )\/\
           \____/|----w |
                ||     ||

	         Moofasa
```
