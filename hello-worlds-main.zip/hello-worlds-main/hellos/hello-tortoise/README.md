# Usage
helloWorldTortoise()
# Result
```
 _____________
< hello world >
 -------------
  \
   \       ___
      oo  // \\
     (_,\/ \_/ \
       \ \_/_\_/>
       /_/   \_\
```
