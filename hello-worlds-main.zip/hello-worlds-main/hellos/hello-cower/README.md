# Usage
helloWorldCower()
# Result
```
 _____________
< hello world >
 -------------
     \
      \
        ,__, |    | 
        (oo)\|    |___
        (__)\|    |   )\_
             |    |_w |  \
             |    |  ||   *

             Cower....
```
