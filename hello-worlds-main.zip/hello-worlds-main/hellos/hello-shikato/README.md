# Usage
helloWorldShikato()
# Result
```
 _____________
< hello world >
 -------------
  \
   \

     Lｰ'{r ｧjｰノ
      _`)-ﾑ{
    /´::( ･)ヽ-- ､
   {::::::::::::::}
   ゝ:::::.ノー-
     しｿ¨UU
```
