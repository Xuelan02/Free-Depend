# Usage
helloWorldTelebears()
# Result
```
 _____________
< hello world >
 -------------
      \                _
       \              (_)   <-- TeleBEARS
        \   ^__^       / \
         \  (oo)\_____/_\ \
            (__)\  you  ) /
                ||----w ((
                ||     ||>> 
```
