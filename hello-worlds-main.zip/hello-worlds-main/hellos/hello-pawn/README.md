# Usage
helloWorldPawn()
# Result
```
 _____________
< hello world >
 -------------
 \
  \
     __
    (  )
     ||
    /__\
   (____)
```
