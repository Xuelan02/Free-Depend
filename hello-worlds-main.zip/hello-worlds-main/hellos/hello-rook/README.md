# Usage
helloWorldRook()
# Result
```
 _____________
< hello world >
 -------------
 \
  \

   WWWWWW
    |  |
    |  |
    |__|
   /____\
  (______)
```
