# Usage
helloWorldBunny()
# Result
```
 _____________
< hello world >
 -------------
  \
   \   \
        \ /\
        ( )
      .( o ).
```
