# Usage
helloWorldKoala()
# Result
```
 _____________
< hello world >
 -------------
  \
   \
       ___  
     {~o_o~}
      ( Y )
     ()~*~()   
     (_)-(_)   
```
