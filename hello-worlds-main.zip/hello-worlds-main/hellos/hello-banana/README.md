# Usage
helloWorldBanana()
# Result
```
 _____________
< hello world >
 -------------
       \
        \

     ".           ,#  
     \ `-._____,-'=/
  ____`._ ----- _,'_____PhS
         `-----'
```
