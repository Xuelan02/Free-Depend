# Usage
helloWorldTableflip()
# Result
```
 _____________
< hello world >
 -------------
  \
(╯°□°）╯︵ ┻━┻
```
