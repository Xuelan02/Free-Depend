# Usage
helloWorldBishop()
# Result
```
 _____________
< hello world >
 -------------
 \
  \
    <>_
  (\)  )
   \__/
  (____)
   |  |
   |__|
  /____\
 (______)
```
